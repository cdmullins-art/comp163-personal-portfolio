# Existing variables you already had
full_name = "Jordan Smith"
student_email = "jsmith@ncat.edu"
hometown = "Charlotte, NC"
graduation = "Spring 2028"
major = "Computer Science"


course_list = ["COMP 163", "MATH 150", "ENG 101", "HIS 105"]
completed_courses = ["Biology", "Chemistry", "Calculus", "Spanish II", "World History"]
credit_hours = [3, 3, 3, 3]
gpa_history = [3.2, 3.6, 3.4, 3.7]


emergency_contact = ("Mom", "Hannah Smith", "704-555-0199")
home_address = ("456 Oak Street", "Charlotte", "NC", 28202)
instagram_info = ("Instagram", "@jordan_codes", 312)
twitter_info = ("Twitter", "@jordandev", 127)
user_birthday = ("Birthday", 5, 22, 2006)


current_skills = {"Python basics", "HTML", "Problem solving", "Time management", "Photography"}
skills_learn = {"JavaScript", "Data structures", "Git", "Web design", "Public speaking"}
career_interest = {"Software development", "Web development", "Data science", "Game development"}
hobbies = {"Gaming", "Photography", "Reading", "Soccer", "Music"}
entertainment = {"One Piece", "Barry", "Life", "Incantation", "Memento"}


credit_dict = {"COMP 163": 3,"MATH 150": 3, "ENG 101": 3, "HIS 105": 3}
professors_dict = {"COMP 163": "Prof. Rhodes", "MATH 150": "Dr. Lee", "ENG 101": "Dr. Martinez", "HIS 105": "Dr. Brown"}
rooms_dict = {"COMP 163": "M-Eric 300", "MATH 150": "Marteena 201", "ENG 101": "Crosby 121", "HIS 105": "Crosby 210"}
budget_dict = {"Food": 450, "Entertainment": 200, "Books": 125, "Transportation": 100}
study_dict = {"Programming": 10, "Math": 8, "English": 4,"History": 3}
contact_dict = {"Mom": "704-555-0199", "Roommate": "336-555-7821", "Academic Advisor": "336-334-5000"}


# === Calculations ===
total_credits = sum(credit_hours)
avg_gpa = sum(gpa_history)/len(gpa_history)
credit_amount = len(course_list)
weekly_study_time = sum(study_dict.values())
academic_investment = budget_dict["Books"] / weekly_study_time
total_budget = sum(budget_dict.values())
food_budget = budget_dict["Food"] / 30
annual_budget = total_budget * 12
follower_count = twitter_info[2] + instagram_info[2]
current_skills_count = len(current_skills)
learning_skills_count = len(skills_learn)
contact_size = len(contact_dict)
entertainment_count = len(entertainment)
academic_assessment = len(hobbies)


# === OUTPUT ===
print("================================================================")
print("              PERSONAL ACADEMIC & LIFE PORTFOLIO")
print("================================================================")
print(f"Student: {full_name} | Email: {student_email}")
print(f"From: {hometown} | Graduating: {graduation}")
print(f"Major: {major}")
print("")
print("=== ACADEMIC PROFILE ===")
print(f"Current Semester: {total_credits} credits across {credit_amount} courses")
print(f"Cumulative GPA: {avg_gpa:.2f}")
print(f"Weekly Study Time: {weekly_study_time} hours")
print(f"Academic Investment: \n${academic_investment:.1f} per study hour")
print("")
print("Current Courses:")
for course in course_list:
   print(f"{course} - {credit_dict[course]} credits - {professors_dict[course]} - {rooms_dict[course]}")
print("")
print("=== PERSONAL DEVELOPMENT ===")
print(f"Current Skills: {current_skills}")
print(f"Learning Goals: {skills_learn}")
print(f"Career Interests: {career_interest}")
print(f"Skills Currently Have: {current_skills_count}")
print(f"Skills Want to Learn: {learning_skills_count}")
print("")
print("=== FINANCIAL OVERVIEW ===")
print(f"Monthly Budget: ${total_budget}")
print(f"Food: ${budget_dict['Food']} (${food_budget:.1f}/day)")
print(f"Entertainment: ${budget_dict['Entertainment']}")
print(f"Books: ${budget_dict['Books']}")
print(f"Transportation: ${budget_dict['Transportation']}")
print(f"Annual Projection: ${annual_budget}")
print("")
print("=== CONNECTIONS & CONTACTS ===")
print(f"Emergency Contact: {emergency_contact[1]} ({emergency_contact[0]}) - {emergency_contact[2]}")
print(f"Home Address: {home_address[0]}, {home_address[1]}, {home_address[2]} {home_address[3]}")
print(f"Social Media Presence: {follower_count} followers across 2 platforms")
print(f"Key Contacts: {contact_size} people in directory")
print("")
print("=== LIFE STATISTICS ===")
print(f"Total Courses Completed: {len(completed_courses)}")
print(f"Current Academic Load: {weekly_study_time + total_credits} weekly commitments")
print(f"Entertainment Backlog: {entertainment_count} items")
print(f"Current Hobbies: {academic_assessment} activities")
print("================================================================")